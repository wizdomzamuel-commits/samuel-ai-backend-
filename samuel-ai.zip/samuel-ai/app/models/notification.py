"""
Notification model.

Represents any piece of incoming information Samuel AI should remember and
later summarize — e.g. a captured app notification, a note, an email digest
line, a task reminder, etc.
"""

import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, Column, DateTime, Enum, String, Text
from sqlalchemy.orm import Mapped

from app.db.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class NotificationSource(str, enum.Enum):
    manual = "manual"
    android = "android"
    email = "email"
    calendar = "calendar"
    other = "other"


class NotificationPriority(str, enum.Enum):
    low = "low"
    normal = "normal"
    high = "high"


class Notification(Base):
    __tablename__ = "notifications"

    id: Mapped[str] = Column(String, primary_key=True, default=_uuid)
    title: Mapped[str] = Column(String(255), nullable=False)
    body: Mapped[str] = Column(Text, nullable=True)
    source: Mapped[str] = Column(Enum(NotificationSource), default=NotificationSource.manual, nullable=False)
    priority: Mapped[str] = Column(Enum(NotificationPriority), default=NotificationPriority.normal, nullable=False)
    app_name: Mapped[str] = Column(String(120), nullable=True)

    is_read: Mapped[bool] = Column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = Column(DateTime(timezone=True), default=_utcnow, nullable=False)

    def __repr__(self) -> str:
        return f"<Notification id={self.id} title={self.title!r} source={self.source}>"
